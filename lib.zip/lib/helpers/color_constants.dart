import 'package:flutter/material.dart';

const kprimaryColor = Color.fromRGBO(0, 171, 89, 1);
const kGreyColor = Color.fromRGBO(223, 223, 223, 1);
const itmGreyColor = Color.fromRGBO(223, 223, 223, 0.3);
const inputGreyColor = Color.fromRGBO(223, 223, 223, .0);
const kLightGrey = Color.fromRGBO(174, 174, 174, 1);
const kYellowColor = Color.fromRGBO(249, 178, 51, 1);
const logoRed = Color.fromRGBO(221, 76, 59, 1);
const logoTitleClr = Color.fromRGBO(138, 143, 53, 1);
const kGrey = Color.fromRGBO(233, 233, 233, 1);
const kGreyText = Color.fromRGBO(154, 149, 141, 1);
const kdividershade =Color.fromRGBO(210, 210, 210, 1);
const kRedColor = Color.fromRGBO(242, 63, 57, 1);
const Color containerGreyShade = Color(0xffe9e9e9);
const Color woodColor = Color(0xffAB5200);
final Color backgroundGreyShade = Color(0xfff3f3f3);
final Color logoDarkBlueColor = Color(0xff0044AB);
final Color logoRedColor = Color(0xffF23F39);
