import 'package:flutter/cupertino.dart';

class VendorCurrentStoreProvider extends ChangeNotifier{

}