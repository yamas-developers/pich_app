import 'package:farmer_app/models/user.dart';
import 'package:farmer_app/models/user_profile.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';

class UserProvider extends ChangeNotifier{
  User? currentUser;
  setUser(User user) {
    currentUser = user;
    notifyListeners();
  }
}